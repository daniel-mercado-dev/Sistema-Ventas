﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace TICKETERA.Models
{
    public class Venta
    {
        public int Id { get; set; }
        public string Sabor { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)")]
        public decimal Precio { get; set; }

        // Agregamos estos para que se guarden en la base de datos
        public int Cantidad { get; set; }
        public string? Promocion { get; set; }
        public string MetodoPago { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;
        
    }
}