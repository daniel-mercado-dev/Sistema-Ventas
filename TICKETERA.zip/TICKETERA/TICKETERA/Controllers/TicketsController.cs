﻿using Microsoft.AspNetCore.Mvc;
using System.Drawing;
using System.Drawing.Printing;
using TICKETERA.Data;
using TICKETERA.Models;
using TICKETERA.Dtos;

namespace TICKETERA.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class TicketsController : ControllerBase
   {

        private readonly ApplicationDbContext _context;

        public TicketsController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpPost("imprimir")]
        public async Task<IActionResult> ImprimirTicket([FromBody] VentaDto venta)
        {
            try
            {
                // 1. GUARDAR EN BASE DE DATOS (Lo que arreglamos antes)
                var nuevaVenta = new Venta
                {
                    Sabor = venta.Sabor,
                    Precio = venta.Precio,
                    Cantidad = venta.Cantidad,
                    Promocion = venta.Promocion,
                    MetodoPago = venta.MetodoPago,
                    Fecha = DateTime.Now
                };
                _context.Ventas.Add(nuevaVenta);
                await _context.SaveChangesAsync();

                // El ID generado servirá como número de orden------------------------------
                int numeroTurno = nuevaVenta.Id;

                // 2. LÓGICA DE IMPRESIÓN CORREGIDA
                string ticketId = DateTime.Now.Ticks.ToString().Substring(08);
                string fechaHora = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");

                PrintDocument pd = new PrintDocument();
                pd.DocumentName = "Ticket_" + ticketId;
                pd.PrinterSettings.PrinterName ="EPSON TM-U220 Receipt";

                pd.PrintPage += (sender, e) =>
                {
                    Graphics g = e.Graphics;
                    float y = 10; // Usamos float para mayor precisión
                    float margenX = 10;
                    float anchoTicket = 180; // Ajustado para Epson TM-U220

                    //---------------------- Aqui se agrega el numero de orden 
                    Font fontOrden = new Font("Courier New", 12, FontStyle.Bold); // Más grande para el número
                    Font fontTitle = new Font("Courier New", 13, FontStyle.Italic);
                    Font fontFecha = new Font("Courier New", 09, FontStyle.Italic);
                    Font fontBody = new Font("Courier New", 12, FontStyle.Bold);
                    Font fontPromo = new Font("Courier New", 12, FontStyle.Italic);
                    Font fontDetalle = new Font("Courier New", 12, FontStyle.Bold);

                    // --- CABECERA CON NÚMERO DE ORDEN ---
                    g.DrawString("ORDEN : #" + numeroTurno, fontBody, Brushes.Black, margenX, y);
                    y += 30;
                    g.DrawString("--------------------------", fontFecha, Brushes.Black, 0, y);
                    y += 15;

                    // 1. TÍTULO
                    g.DrawString("DULCES LIMEÑOS ASTRID", fontTitle, Brushes.Black, margenX, y);
                    y += 20;

                    // 2. FECHA
                    g.DrawString("FECHA: " + fechaHora, fontFecha, Brushes.Black, margenX, y);
                    y += 20;

                    // 3. SEPARADOR
                    g.DrawString("--------------------------", fontFecha, Brushes.Black, 0, y);
                    y += 15;

                    // 4. CABECERA DETALLE
                    g.DrawString("DETALLE DEL PEDIDO:", fontTitle, Brushes.Black, margenX, y);
                    y += 20;

                    // 5. PROCESAR CONTENIDO (SABORES Y PRODUCTOS)
                    string[] separadores = new string[] { " + ", "\n", "\r\n" };
                    string[] lineas = venta.Sabor.Split(separadores, StringSplitOptions.RemoveEmptyEntries);

                    foreach (var linea in lineas)
                    {
                        string textoLimpio = linea.Trim().TrimStart('•', '-', ' ');
                        // Si el texto contiene "S/", es un producto individual, si no, es parte de una lista
                        string textoADibujar = lineas.Length > 1 ? " • " + textoLimpio.ToUpper() : textoLimpio.ToUpper();

                        // Medimos cuánto espacio ocupa esta línea específica
                        SizeF size = g.MeasureString(textoADibujar, fontDetalle, (int)anchoTicket);

                        g.DrawString(textoADibujar, fontDetalle, Brushes.Black, new RectangleF(margenX, y, anchoTicket, size.Height));

                        // INCREMENTO DINÁMICO: Bajamos exactamente lo que midió el texto + un pequeño respiro
                        y += size.Height + 2;
                    }

                    // 6. PROMOCIÓN (Solo si existe y no es el mensaje por defecto)
                    if (!string.IsNullOrWhiteSpace(venta.Promocion) &&
                        venta.Promocion != "Atención en Mesa" &&
                        !venta.Sabor.Contains(venta.Promocion)) // Evita duplicar si ya está en el nombre
                    {
                        y += 10;
                        g.DrawString("PROMO: " + venta.Promocion, fontPromo, Brushes.Black, margenX, y);
                        y += 20;
                    }

                    // 7. SEPARADOR PRE-TOTAL
                    y += 5;
                    g.DrawString("--------------------------", fontFecha, Brushes.Black, 0, y);
                    y += 15;

                    // 8. TOTAL (Bien separado del resto)
                    g.DrawString("TOTAL A PAGAR: S/ " + venta.Precio.ToString("N2"), fontDetalle, Brushes.Black, margenX, y);
                    y += 30;

                    // 9. PIE DE PÁGINA
                    g.DrawString("¡GRACIAS POR SU COMPRA!", fontFecha, Brushes.Black, margenX, y);

                    // 10. ESPACIO PARA CORTE (Importante para que no se quede la última línea dentro)
                    y += 50;
                    g.DrawString(".", fontBody, Brushes.Transparent, 0, y);

                    e.HasMorePages = false;
                
            };

                _ = Task.Run(() =>
                {
                    try
                    {
                        pd.Print();
                        
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("ERROR DE IMPRESORA: " + ex.Message);
                    }
                });

                // 4. RESPUESTA INMEDIATA A LA WEB
                return Ok(new
                {
                    success = true,
                    turno = numeroTurno,
                    mensaje = "Venta registrada. Imprimiendo..."
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { success = false, mensaje = "Error en BD: " + ex.Message });
            }
        }
    }
}