﻿namespace TICKETERA.Dtos
{
    public class VentaDto
    {
        public string Sabor { get; set; }
        public decimal Precio { get; set; }
        public int Cantidad { get; set; }
        public string Promocion { get; set; }
        public string MetodoPago { get; set; } // <--- REVISA QUE ESTÉ ASÍ
    }
}
