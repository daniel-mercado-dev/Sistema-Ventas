﻿using Microsoft.EntityFrameworkCore;
using TICKETERA.Models; // Esto permite que el contexto vea a Venta.cs

namespace TICKETERA.Data // Cambiado para que coincida con la carpeta Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        // Esta es la línea que crea la conexión con la tabla de SQL
        public DbSet<Venta> Ventas { get; set; }
    
    public DbSet<Inventario> InventarioDiario { get; set; }
    }
}